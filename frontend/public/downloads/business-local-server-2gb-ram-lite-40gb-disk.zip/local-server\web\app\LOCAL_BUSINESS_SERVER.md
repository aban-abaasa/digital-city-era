# Optional local server for a business

> **Current preview behavior:** the installer binds the app and API to
> `127.0.0.1` by default, so only the server computer can connect. Businesses
> that need other devices to connect can choose LAN access during setup. In
> either mode, the sync agent connects outbound to the cloud and uploads
> supported queued changes when internet is available.

## Goal

Let a business opt into a server on its own premises. Staff devices on that
business's Wi-Fi/LAN can keep using supported business features when the
internet connection is down. When the connection returns, the local server
syncs with the shared cloud Supabase project used by the applications.

The feature is optional. Businesses without a local server continue using the
hosted applications and shared cloud Supabase as they do today.

Each business server must contain only that business's data. The shared cloud
project remains the cross-business source of truth and the local server is an
offline operating node, not a separate cloud account or an unrestricted copy
of the shared database.

## Device and server platform support

Treat server hosting and staff-device support as separate things:

- **Server host:** provide a guided setup for a Windows PC with Docker Desktop,
  a Mac with Docker Desktop, or a Linux server/desktop with Docker. Supabase's
  one-command `setup.sh` is Linux-only; Windows and macOS need the manual
  Docker Compose setup in the official self-hosting guide. Start with these
  three host platforms, and list any additional Docker-compatible host only
  after it is supported and maintained by the installer.
- **Staff clients:** Windows, macOS, Linux, iPhone/iPad, and Android devices
  connect to the business server over its Wi-Fi/LAN using the app in a
  supported browser or installed PWA. They do not install or run Supabase.
- **Phone/tablet as server:** do not promise that Android or iPhone/iPad can
  host the Supabase stack. Keep mobile devices as clients; use a PC or server
  on the business network for the local node.
- **Offline requirement:** a device must have opened/installed the LAN app
  while connected to that business network. The LAN app and API need a
  secure-origin plan so browser storage, authentication, and PWA behavior work
  across devices.

Supabase documents Docker-based self-hosting for Linux, macOS, and Windows,
but its automated `setup.sh` supports Linux only. It also calls out a macOS
Docker Desktop bind-mount limitation that can affect Storage; the business
deployment must use the documented named-volume workaround or verify its
Storage configuration before promising file uploads. See the official
[self-hosting platform and storage guidance](https://supabase.com/docs/guides/self-hosting/docker).

## Current state in this repository

- The main Supabase clients in Digital City Era, ICAN, and mybodaguy can use a
  deployment-specific public `/runtime-config.js` (`supabaseUrl`,
  `supabaseAnonKey`), with their existing Vite build-time settings as fallback.
  ICAN's MOMO function URL uses the same override. Runtime config must contain
  only public client settings, never a `service_role` key.
- Digital City Era's POS uses the shared Supabase client when runtime settings
  are provided. Its legacy cloud client remains as the cloud-only fallback.
- Business settings link to `/business-local-server` from the profile,
  supermarket admin, manager, cashier, supplier, POS, and ICAN wallet screens.
  The shared account menu also exposes the same setup page across app portals,
  including the BodaGo dashboard. That owner-facing page creates one-use,
  ten-minute pairing codes, lists paired nodes, and revokes nodes. The
  following cloud migrations are a one-time platform deployment handled by
  the Digital City Era platform administrator; customers do not run SQL. Apply
  the tax-setting migrations `ADD_SUPERMARKET_TAX_INCLUSION_SETTING.sql` then
  `ADD_PRODUCT_TAX_INCLUSION_OVERRIDE.sql` if not already installed. Then apply
  `backend/database/migrations/ADD_BUSINESS_LOCAL_SYNC_CONTROL_PLANE.sql`,
  `backend/database/migrations/ADD_BUSINESS_LOCAL_TEAM_MESSAGE_SYNC.sql`, and
  `backend/database/migrations/ADD_BUSINESS_LOCAL_SYNC_PROTOCOL_V2.sql`,
  then `backend/database/migrations/ADD_BUSINESS_LOCAL_CATALOG_SYNC.sql`,
  followed by `ADD_BUSINESS_LOCAL_STOCK_ADJUSTMENTS.sql`,
  `ADD_BUSINESS_LOCAL_CASH_SALES.sql`, and
  `ADD_BUSINESS_LOCAL_PRODUCT_EDITING.sql` to the cloud project. The customer setup
  page checks readiness and directs customers to support if platform setup is
  missing. The shared cloud project must already
  have the Digital City Era `public.products` and `public.inventory` tables;
  these sync migrations do not install the full app schema.
- `local-server/agent` transports typed team-message and supermarket-catalog
  events, writes incoming rows to local tables, and quarantines event types it
  does not understand. Pairing seeds existing team history and catalog data;
  reapplying the latest migration also backfills active nodes paired earlier.
- `local-server/installers/install.js` and `local-server/package-preview.ps1`
  build three cross-platform installer ZIPs for different RAM/disk tiers. The
  installer packages the app shell, pins the upstream Supabase Docker release,
  creates local keys, claims the owner pairing code, binds app/API ports to
  loopback by default or a selected LAN IPv4 address, blocks host ports for
  Postgres, Supavisor, and Studio, and starts the transport worker.
- `local-server/agent/src/claim-node.js` can also be run by itself to claim an
  owner-generated pairing code and write the node credential to a server-side
  `.env.local-sync` file.
- Sync envelopes carry a schema version, stable event ID, registered source
  node, and original `occurred_at`; cloud `created_at` remains the receipt time.
  Protocol v3 acknowledges cloud events only after they are durable in the
  local inbox. Pairing checks the team-history and catalog bootstrap versions
  before it consumes a one-time pairing code.
- If cloud migrations have not been applied to the shared Supabase project,
  customer pairing stays unavailable and the setup page directs customers to
  their platform administrator/support. The customer does not apply SQL.
- The installer offers Full (the existing 4 GB option) and Lite (2 GB minimum
  option). Both editions mirror this supermarket's products, prices, and stock,
  support product edits and Admin stock corrections, and save cash sales locally.
  Full serves the LAN team channel; Lite leaves optional services and team chat stopped. Neither
  edition searches or loads other stores' product names. Cross-store product
  suggestions are available only in connected online add forms. Both use local
  Admin/Cashier PIN accounts, with the first setup account as Admin. Cash sales
  are stored on the shared local node, reduce local stock atomically, print a
  receipt, and sync to cloud transactions when the platform administrator has
  enabled cloud sync and internet returns. Other app schemas, TLS, backup, and
  update/rollback remain to be built.
- Digital City Era's cashier PWA caches the app and a business's product
  catalog/profile on each device, and queues cash sales in IndexedDB. It sends
  queued sales directly to the configured Supabase endpoint when reachable.
- The cashier browser queue is device-specific in cloud mode. Local-server
  cash sales instead use the shared LAN database and update the node's stock
  mirror before a receipt is shown. Sale records wait in the node outbox until
  the sync worker can reach cloud Supabase.
- Other features call Supabase directly. They do not automatically use the
  cashier queue, and payment/authentication flows that require a live service
  remain online-dependent.

The repository has a downloadable **business-server preview** with Full and
Lite installer choices. Team chat works over the LAN in Full and syncs after
reconnection; both editions support local catalog edits, stock corrections,
cash sales, and durable receipt history.
The server catalog is scoped to the paired store and never suggests products
from other stores. It is not a complete offline business system: other app
workflows, full app schemas, TLS, backup, and update/rollback are still missing.
Wallet payments still need the internet.

## What the Supabase installer does

Supabase documents `curl -fsSL https://supabase.link/setup.sh | sh` as a
Linux self-hosting quick start. On supported Debian/Ubuntu and
RHEL/CentOS/Fedora systems, it can install prerequisites and Docker Engine,
fetch the Supabase Docker configuration, generate secrets, prompt for URLs,
and pull the container images. The resulting Supabase stack is a database/API
installation. It does not provision this application's business account,
install this application's frontend, filter the shared cloud data to one
business, or establish cloud synchronization.

Supabase's setup script targets Linux; manual Docker Compose setup is needed
for Windows and macOS hosts. Mobile devices connect as LAN clients rather than
hosting the stack. Supabase documents those supported host environments in its
[self-hosting Docker guide](https://supabase.com/docs/guides/self-hosting/docker).

The setup script needs internet access while it downloads code and container
images. After setup, local devices can reach the server over the business LAN
without an internet connection. Updates and disaster recovery still need a
planned internet/maintenance path.

Official references:

- [Supabase self-hosting with Docker](https://supabase.com/docs/guides/self-hosting/docker)
- [Supabase self-hosting overview](https://supabase.com/docs/guides/self-hosting)

## Intended business setup experience

1. A business owner opens **Offline server settings** from their business
   settings (or profile) while online from a supported desktop browser
   (`/business-local-server`).
2. The cloud checks that the owner can administer the selected business, then
   issues a short-lived, single-use pairing code. No cloud service-role key is
   given to the business.
3. The operator downloads and runs the business-server preview package on a
   Windows, macOS, or Linux host with Node.js, Git, Docker, and recent Docker
   Compose. Windows also requires Git Bash. The installer pins Supabase
   `self-hosted/v0.8.1`, offers Full (4 GB RAM) or Lite (2 GB RAM) packages,
   generates local secrets, and defaults to loopback-only access. An optional
   LAN mode binds to the selected business IPv4 address. At startup it creates
   a **STIMA** shortcut on the host computer to open the selected app address.
4. The installer claims the pairing code, enrolls one node for that business,
   and stores its credential in `.env.local-sync` on the server. It also
   removes host-published Postgres/Supavisor ports and persists Storage in a
   named Docker volume.
5. The installer serves the built app shell, creates a one-use Admin setup
   code, and installs local staff sign-in with Admin/Cashier accounts. Full
   configures the business-scoped text team channel; Lite omits Realtime and
   other optional services. It does not load the full app schema or sales data.
6. In local-only mode, the host opens `http://127.0.0.1:8080`. If LAN mode was
   selected, devices on the same trusted LAN open the reserved server address
   at port 8080. The Admin uses the setup code once, creates local PIN
   accounts, then each worker signs in locally. The local database validates
   staff identity for local operations. At first setup, the Admin also enters
   the store name used on local receipts.
7. When internet returns, the agent syncs supported local catalog, stock,
   cash-sale, and (in Full) team-message events for the paired business.
   Unsupported event types are quarantined.

The generated server must have a supported local HTTPS/address strategy for
the app origin, Supabase API, and authentication redirects. A service worker
does not make an internet-hosted app available to new LAN devices during an
outage; the frontend itself must be served on the LAN and installed/cached
before it is needed offline.

## Sync contract required before rollout

Do not copy or logically replicate the entire shared database into each
business node. Build an explicit business-scoped sync protocol:

- Enroll a node with a stable node ID, business ID, schema version, and
  revocable credentials. Never put Supabase `service_role` secrets in a
  browser, installer output, or downloadable app bundle.
- Bootstrap only rows authorized for that business. Enforce the business
  boundary on the server; do not trust a business ID supplied by the client.
- Give every offline-created operation a stable UUID/idempotency key and
  record its origin node and original event time. Retrying after an
  acknowledgment is lost must not create duplicate sales, messages, payments,
  or stock movements.
- Use append-only events for sales, team messages, and stock movements where
  possible. Resolve inventory from movements and reconciliation rules rather
  than silently overwriting a newer stock count.
- Define cloud-to-node and node-to-cloud rules per table. For example, shared
  catalog/configuration changes can flow cloud-to-node; locally recorded
  sales/messages can flow node-to-cloud. Mutable records need explicit
  version/conflict behavior; last-write-wins is not safe for money or stock.
- Keep a durable outbound queue, retry with backoff, record acknowledgments,
  surface permanent failures, and provide an operator-visible sync log.
- Review and revoke local staff access deliberately. Cloud Supabase Auth and
  the separate local PIN service do not share users, passwords, or sessions.
- Back up and restore the local database and uploaded files. Verify that
  restoring a node does not replay already-acknowledged operations twice.

## Build sequence

1. Inventory every app's business-owned tables and write a data ownership and
   authority matrix. Include ICAN and mybodaguy integrations that share the
   cloud Supabase project; do not assume every table belongs to the store.
2. Add node enrollment, business-scoped bootstrap, revocation, and the
   idempotent event/outbox protocol in the cloud backend.
3. Add the local node agent and versioned migrations. Team messaging,
   cloud-to-node supermarket catalog updates, local PIN accounts, and shared
   LAN cash sales are implemented in preview. Continue appending other local
   workflows with explicit idempotency and conflict handling.
4. Finish converting all frontend Supabase client creation to a single
   validated runtime config supplied by the LAN deployment. The primary
   shared client and POS local-mode branch use runtime settings; other direct
   Supabase client constructors still need an app-wide audit. Serve the local
   app and API through a supported secure origin.
5. Expand the cross-platform business-server preview into a production
   installer: add the versioned app schema, HTTPS/certificate enrollment,
   backup/restore, and update/rollback. The current
   package pins Supabase, includes the app shell, creates unique local keys,
   binds the app/API to one LAN address, and blocks database/Studio host ports.
6. Verify one-business isolation, offline LAN operation, cloud reconnection,
   duplicate retries, concurrent stock changes, auth expiry, update/rollback,
   backup/restore, and node revocation before offering the download broadly.

## Current supported behavior vs. target

| Capability | Current repository | Target local server |
| --- | --- | --- |
| Cashier cash sale during outage | Queued on that browser/device | Cash sale saved to the LAN ledger, local stock reduced, then synced once |
| POS catalog during outage | Cached on that browser/device | Read-only product mirror with atomic stock deduction for local cash sales |
| Team messages during outage | Text-only LAN preview with cloud sync | Authenticated team messaging over a secure LAN |
| Other business tables/features | Mostly direct cloud Supabase calls | Enabled only after a table-specific sync path exists |
| Per-business Supabase download | App-shell/server preview with local PIN accounts, mirrored catalog, and cash-sale ledger | Guided node enrollment/install with app bootstrap |
| Cloud/local database sync | Business-scoped team text, catalog, stock, product, and cash-sale events after included migrations are applied | Sync for sales, inventory, messages, and other workflows |
