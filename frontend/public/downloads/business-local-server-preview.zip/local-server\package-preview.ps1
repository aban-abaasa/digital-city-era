$ErrorActionPreference = 'Stop'

$localServerRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $localServerRoot
$stageId = [Guid]::NewGuid().ToString('N')
$stageRoot = Join-Path ([System.IO.Path]::GetTempPath()) "dce-local-server-package-$stageId"
$stagedPackage = Join-Path $stageRoot 'local-server'
$downloadsDirectory = Join-Path $projectRoot 'frontend\public\downloads'
$archivePath = Join-Path $downloadsDirectory 'business-local-server-preview.zip'

New-Item -ItemType Directory -Path $stagedPackage -Force | Out-Null
New-Item -ItemType Directory -Path $downloadsDirectory -Force | Out-Null

try {
  Copy-Item -LiteralPath (Join-Path $localServerRoot 'agent') -Destination $stagedPackage -Recurse
  Copy-Item -LiteralPath (Join-Path $localServerRoot 'installers') -Destination $stagedPackage -Recurse
  Copy-Item -LiteralPath (Join-Path $localServerRoot 'INSTALL_PREVIEW.md') -Destination $stagedPackage
  Compress-Archive -Path $stagedPackage -DestinationPath $archivePath -CompressionLevel Optimal -Force
  Get-FileHash -LiteralPath $archivePath -Algorithm SHA256 | Format-List
  Write-Output "Created $archivePath"
} finally {
  $resolvedStageRoot = [System.IO.Path]::GetFullPath($stageRoot)
  $systemTempRoot = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath())
  if ($resolvedStageRoot.StartsWith($systemTempRoot, [System.StringComparison]::OrdinalIgnoreCase) -and
      (Split-Path -Leaf $resolvedStageRoot).StartsWith('dce-local-server-package-')) {
    Remove-Item -LiteralPath $resolvedStageRoot -Recurse -Force
  }
}
