# Local sync node installer preview

This package installs a business-specific self-hosted Supabase stack and the
cloud pairing/sync transport worker. The stack is pinned to Supabase's
`self-hosted/v0.8.2` Docker release.

**This is infrastructure preview software.** It does not install the Digital
City Era, ICAN, or BodaGoEra frontend or their database schemas. It does not
sync sales, inventory, team messages, or other app records yet. Do not use it
for live business data.

## Requirements

- Windows 10/11 with Docker Desktop in Linux-container mode and Git for Windows
  (Git Bash must be available as `bash`), or macOS with Docker Desktop, or a
  Linux host with Docker Engine and Compose.
- Node.js 20 or newer, Git, a running Docker engine, and Docker Compose 2.24.4
  or newer.
- At least 4 GB RAM, 2 CPU cores, and 40 GB free disk space.
- Internet during initial setup to download the pinned Supabase files and
  container images.
- A fixed/reserved IPv4 address for the server on the business LAN.
- The cloud migration
  `backend/database/migrations/ADD_BUSINESS_LOCAL_SYNC_CONTROL_PLANE.sql`
  applied to the shared cloud Supabase project.

## Install

1. While signed in as the business owner, open the app's **Profile → Offline
   server** page and create a one-time pairing code.
2. Download and extract this package on the server computer.
3. Open a terminal in the extracted package directory and run:

   ```sh
   node local-server/installers/install.js
   ```

4. Enter a new installation folder, the server's reserved LAN IPv4 address,
   and type `YES` after reviewing the preview limitation. The installer then
   asks for the cloud Supabase project URL, public anon/publishable key, and
   the one-time pairing code.

The installer generates unique local keys, keeps the local API gateway bound
to the selected LAN interface, removes Supavisor's host-published database
ports, uses a persistent Docker volume for Storage, installs the sync queue
tables, and starts the local stack plus transport agent. The generated
`.env` and `.env.local-sync` files contain private server credentials; keep
them on the server computer and restrict the Windows account or POSIX file
permissions that can read them.

Do not forward port 8000 from the business router to the public internet. Keep
the machine and Wi-Fi on a trusted business LAN. The preview uses HTTP; its
authentication traffic is not suitable for live customer or business data.

## After installation

The local Supabase gateway listens at `http://<reserved-lan-ip>:8000`. The
local node is registered to one business in cloud control-plane metadata. The
agent retries outbound envelopes and stores inbound envelopes, but the app
does not yet produce or apply business events. The web frontend is not hosted
by this package.

To stop the stack, run from the chosen installation folder:

```sh
docker compose --env-file .env --env-file .env.local-sync \
  -f docker-compose.yml -f docker-compose.local-business.yml down
```

This command stops containers but keeps the database and Storage data. Do not
use `down -v` unless you intend to delete them. Automated backup, restore,
updates, rollback, TLS certificates, local app hosting, account provisioning,
and business-event handlers still need to be added before production use.
