#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { cpSync, copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statfsSync, chmodSync, writeFileSync } from 'node:fs';
import { tmpdir, homedir, platform, totalmem, availableParallelism } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const installerDir = dirname(fileURLToPath(import.meta.url));
const packageRoot = resolve(installerDir, '..');
const upstreamTag = 'self-hosted/v0.8.2';
const composeMinimum = [2, 24, 4];
const prompt = createInterface({ input: stdin, output: stdout });

function failIf(command, args, label, options = {}) {
  const result = spawnSync(command, args, {
    cwd: options.cwd,
    encoding: 'utf8',
    input: options.input,
    stdio: options.inherit ? 'inherit' : 'pipe',
    windowsHide: true,
    maxBuffer: 12 * 1024 * 1024,
  });
  if (result.error || result.status !== 0) {
    const detail = options.showError ? String(result.stderr || result.error?.message || '').trim() : '';
    throw new Error(`${label}${detail ? `: ${detail.slice(-800)}` : ''}`);
  }
  return String(result.stdout || '').trim();
}

function shellCommand() {
  const shell = platform() === 'win32' ? 'bash' : 'sh';
  const probeArgs = platform() === 'win32'
    ? ['--noprofile', '--norc', '-c', 'exit 0']
    : ['-c', 'exit 0'];
  const check = spawnSync(shell, probeArgs, { encoding: 'utf8', windowsHide: true });
  if (check.error || check.status !== 0) {
    if (platform() === 'win32') {
      throw new Error('Install Git for Windows with Git Bash, then run this installer from a terminal where `bash` is available.');
    }
    throw new Error('A POSIX shell is required to run the upstream Supabase key generator.');
  }
  return shell;
}

function composeVersion() {
  const output = failIf('docker', ['compose', 'version', '--short'], 'Docker Compose is required');
  const match = output.match(/(\d+)\.(\d+)\.(\d+)/);
  if (!match) throw new Error(`Could not read Docker Compose version from: ${output}`);
  const actual = match.slice(1).map(Number);
  const tooOld = actual.some((part, index) => part < composeMinimum[index] && actual.slice(0, index).every((n, i) => n === composeMinimum[i]));
  if (tooOld) throw new Error(`Docker Compose ${composeMinimum.join('.')} or newer is required for the secure local-storage/port overrides (found ${match[0]}).`);
  return match[0];
}

function isIpv4Address(value) {
  const parts = value.split('.');
  return parts.length === 4 && parts.every((part) => /^\d{1,3}$/.test(part) && Number(part) >= 0 && Number(part) <= 255);
}

function checkRequirements() {
  const currentNode = Number(process.versions.node.split('.')[0]);
  if (currentNode < 20) throw new Error('Node.js 20 or newer is required.');
  failIf('git', ['--version'], 'Git is required');
  const composeVer = composeVersion();
  const shell = shellCommand();
  failIf('docker', ['info'], 'Docker is installed but its engine is not running');
  if (totalmem() < 4 * 1024 ** 3) throw new Error('This Supabase stack needs at least 4 GB RAM.');
  if (availableParallelism() < 2) throw new Error('This Supabase stack needs at least 2 CPU cores.');
  return { composeVer, shell };
}

function setEnvValue(envText, key, value) {
  const line = new RegExp(`^${key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}=.*$`, 'm');
  if (!line.test(envText)) throw new Error(`Expected setting ${key} was missing from Supabase .env.example.`);
  return envText.replace(line, `${key}=${value}`);
}

function runCompose(projectDir, envFiles, files, args, { input, inherit = true } = {}) {
  const parameters = [];
  for (const envFile of envFiles) parameters.push('--env-file', envFile);
  for (const composeFile of files) parameters.push('-f', composeFile);
  parameters.push(...args);
  return failIf('docker', ['compose', ...parameters], `Docker Compose command failed (${args.join(' ')})`, {
    cwd: projectDir,
    input,
    inherit,
    showError: true,
  });
}

async function ask(label, fallback = '') {
  const answer = (await prompt.question(fallback ? `${label} [${fallback}]: ` : `${label}: `)).trim();
  return answer || fallback;
}

async function main() {
  console.log('\nDigital City Era local sync node preview');
  console.log('This installs self-hosted Supabase and an event transport agent.');
  console.log('It does not yet install the business app, its schema, or real sales/chat sync handlers.');
  console.log('The generated API endpoint uses HTTP on your LAN; do not use it for live business data yet.\n');

  const { composeVer, shell } = checkRequirements();
  const defaultDir = join(homedir(), 'DigitalCityLocalServer');
  const targetDir = resolve(await ask('Install folder', defaultDir));
  const lanHost = await ask('Server LAN IPv4 address (reserve this address in your router)');
  if (!isIpv4Address(lanHost)) throw new Error('Enter the server computer IPv4 address on the business LAN.');

  mkdirSync(dirname(targetDir), { recursive: true });
  const parentInfo = statfsSync(dirname(targetDir));
  const freeBytes = Number(parentInfo.bavail) * Number(parentInfo.bsize);
  if (freeBytes < 40 * 1024 ** 3) throw new Error('At least 40 GB of free disk space is required for the self-hosted stack and data.');
  if (existsSync(targetDir)) {
    throw new Error(`Install folder already exists: ${targetDir}. Choose a new empty folder; existing data is never overwritten.`);
  }

  const accepted = await ask('This is a transport preview, not production offline app service. Continue? Type YES');
  if (accepted !== 'YES') throw new Error('Installation cancelled.');

  mkdirSync(targetDir, { recursive: true });
  if (platform() !== 'win32') chmodSync(targetDir, 0o700);

  const tempCheckout = join(tmpdir(), `dce-supabase-${Date.now()}-${Math.random().toString(16).slice(2)}`);
  mkdirSync(tempCheckout, { recursive: true });
  try {
    console.log(`\nFetching the pinned Supabase self-hosted release (${upstreamTag})...`);
    failIf('git', [
      'clone', '--depth', '1', '--filter=blob:none', '--sparse',
      '--single-branch', '--branch', upstreamTag,
      'https://github.com/supabase/supabase.git', tempCheckout,
    ], 'Could not download the pinned Supabase Docker configuration', { showError: true });
    failIf('git', ['sparse-checkout', 'set', 'docker'], 'Could not select the Supabase Docker configuration', { cwd: tempCheckout, showError: true });

    const upstreamDocker = join(tempCheckout, 'docker');
    for (const entry of readdirSync(upstreamDocker)) {
      cpSync(join(upstreamDocker, entry), join(targetDir, entry), {
        recursive: true,
        errorOnExist: true,
        force: false,
      });
    }
  } finally {
    const safeTempRoot = resolve(tmpdir());
    const resolvedTemp = resolve(tempCheckout);
    if (resolvedTemp.startsWith(`${safeTempRoot}${process.platform === 'win32' ? '\\' : '/'}`)) {
      rmSync(resolvedTemp, { recursive: true, force: true });
    }
  }

  const packagedAgent = join(packageRoot, 'agent');
  if (!existsSync(join(packagedAgent, 'src', 'index.js'))) throw new Error('The installer bundle is missing its sync agent files.');
  const installedAgent = join(targetDir, 'local-server', 'agent');
  mkdirSync(dirname(installedAgent), { recursive: true });
  cpSync(packagedAgent, installedAgent, { recursive: true, errorOnExist: true, force: false });
  copyFileSync(join(packagedAgent, 'docker-compose.override.yml'), join(targetDir, 'docker-compose.local-business.yml'));
  copyFileSync(join(targetDir, '.env.example'), join(targetDir, '.env'));

  console.log('\nGenerating unique local Supabase keys and passwords...');
  failIf(shell, ['utils/generate-keys.sh', '--update-env'], 'Could not generate local Supabase secrets', { cwd: targetDir });
  failIf(shell, ['utils/add-new-auth-keys.sh', '--update-env'], 'Could not generate local Supabase API keys', { cwd: targetDir });
  for (const backup of ['.env.old']) {
    const backupPath = join(targetDir, backup);
    if (existsSync(backupPath)) rmSync(backupPath, { force: true });
  }

  let envText = readFileSync(join(targetDir, '.env'), 'utf8');
  envText = setEnvValue(envText, 'SUPABASE_PUBLIC_URL', `http://${lanHost}:8000`);
  envText = setEnvValue(envText, 'API_EXTERNAL_URL', `http://${lanHost}:8000/auth/v1`);
  envText = setEnvValue(envText, 'SITE_URL', `http://${lanHost}:3000`);
  envText = setEnvValue(envText, 'ADDITIONAL_REDIRECT_URLS', `http://${lanHost}:3000`);
  envText = `${envText.trimEnd()}\nLOCAL_SERVER_BIND_IP=${lanHost}\n`;
  envText = setEnvValue(envText, 'DISABLE_SIGNUP', 'true');
  envText = setEnvValue(envText, 'POOLER_TENANT_ID', 'digital-city-local');
  writeFileSync(join(targetDir, '.env'), envText, 'utf8');
  if (platform() !== 'win32') chmodSync(join(targetDir, '.env'), 0o600);

  console.log('\nClaim the one-time code created on the owner setup page.');
  const claim = spawnSync(process.execPath, [join(installedAgent, 'src', 'claim-node.js'), '.env.local-sync'], {
    cwd: targetDir,
    stdio: 'inherit',
    windowsHide: true,
  });
  if (claim.error || claim.status !== 0) throw new Error('Pairing did not complete. The owner can revoke any uncertain node and create a fresh code.');

  const baseCompose = join(targetDir, 'docker-compose.yml');
  const localCompose = join(targetDir, 'docker-compose.local-business.yml');
  const envFiles = [join(targetDir, '.env'), join(targetDir, '.env.local-sync')];
  const composeFiles = [baseCompose, localCompose];

  console.log('\nPulling the pinned Supabase services and starting the local database...');
  runCompose(targetDir, envFiles, composeFiles, ['pull', 'db', 'api-gw', 'auth', 'rest', 'realtime', 'storage', 'imgproxy', 'meta', 'functions', 'studio', 'supavisor']);
  runCompose(targetDir, envFiles, composeFiles, ['up', '-d', '--wait', 'db']);

  console.log('Creating local sync inbox/outbox tables...');
  const syncSql = readFileSync(join(installedAgent, 'sql', 'local-sync-storage.sql'), 'utf8');
  runCompose(targetDir, envFiles, composeFiles,
    ['exec', '-T', 'db', 'psql', '-U', 'postgres', '-d', 'postgres', '-v', 'ON_ERROR_STOP=1'],
    { input: syncSql, inherit: false }
  );

  console.log('\nStarting the local Supabase stack and sync transport...');
  runCompose(targetDir, envFiles, composeFiles, ['up', '-d', '--build', '--wait']);

  console.log('\nLocal sync node infrastructure is running.');
  console.log(`Local Supabase API: http://${lanHost}:8000`);
  console.log(`Install directory: ${targetDir}`);
  console.log(`Docker Compose: ${composeVer}`);
  console.log('Keep this server on the business LAN. Do not forward its ports from the internet.');
  console.log('The business app, local schema, HTTPS LAN address, and workflow sync handlers still need to be installed before staff can work offline.');
}

try {
  await main();
} catch (error) {
  console.error(`\nSetup stopped: ${error.message || error}`);
  process.exitCode = 1;
} finally {
  prompt.close();
}
