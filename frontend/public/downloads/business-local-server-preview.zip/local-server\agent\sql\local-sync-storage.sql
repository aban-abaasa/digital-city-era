-- Local-only storage for the business sync agent. Apply this to the local
-- Supabase database after the business app schema is installed.

CREATE TABLE IF NOT EXISTS public.business_local_sync_outbox (
  event_id UUID PRIMARY KEY,
  event_type TEXT NOT NULL CHECK (event_type ~ '^[a-z][a-z0-9_.-]{2,63}$'),
  payload JSONB NOT NULL CHECK (jsonb_typeof(payload) = 'object'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  synced_at TIMESTAMPTZ,
  last_error TEXT
);

CREATE INDEX IF NOT EXISTS idx_business_local_sync_outbox_pending
  ON public.business_local_sync_outbox(created_at)
  WHERE synced_at IS NULL;

CREATE TABLE IF NOT EXISTS public.business_local_sync_inbox (
  cursor BIGINT PRIMARY KEY,
  event_id UUID NOT NULL UNIQUE,
  event_type TEXT NOT NULL CHECK (event_type ~ '^[a-z][a-z0-9_.-]{2,63}$'),
  payload JSONB NOT NULL CHECK (jsonb_typeof(payload) = 'object'),
  created_at TIMESTAMPTZ NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  applied_at TIMESTAMPTZ,
  last_error TEXT
);

CREATE INDEX IF NOT EXISTS idx_business_local_sync_inbox_unapplied
  ON public.business_local_sync_inbox(cursor)
  WHERE applied_at IS NULL;

CREATE TABLE IF NOT EXISTS public.business_local_sync_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT '',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.business_local_sync_outbox ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_local_sync_inbox ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_local_sync_meta ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.business_local_sync_outbox FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.business_local_sync_inbox FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.business_local_sync_meta FROM PUBLIC, anon, authenticated;

GRANT ALL ON TABLE public.business_local_sync_outbox TO service_role;
GRANT ALL ON TABLE public.business_local_sync_inbox TO service_role;
GRANT ALL ON TABLE public.business_local_sync_meta TO service_role;
