const requiredEnvironment = [
  'LOCAL_SUPABASE_URL',
  'LOCAL_SUPABASE_SERVICE_ROLE_KEY',
  'CLOUD_SUPABASE_URL',
  'CLOUD_SUPABASE_ANON_KEY',
  'BUSINESS_SYNC_NODE_ID',
  'BUSINESS_SYNC_NODE_SECRET',
];

for (const name of requiredEnvironment) {
  if (!process.env[name]) throw new Error(`Missing required environment value: ${name}`);
}

const localBaseUrl = process.env.LOCAL_SUPABASE_URL.replace(/\/$/, '');
const localKey = process.env.LOCAL_SUPABASE_SERVICE_ROLE_KEY;
const cloudBaseUrl = process.env.CLOUD_SUPABASE_URL.replace(/\/$/, '');
const cloudAnonKey = process.env.CLOUD_SUPABASE_ANON_KEY;
const nodeId = process.env.BUSINESS_SYNC_NODE_ID;
const nodeSecret = process.env.BUSINESS_SYNC_NODE_SECRET;
const pollMs = Math.max(5000, Number(process.env.BUSINESS_SYNC_POLL_MS) || 15000);
const batchSize = 100;
const requestTimeoutMs = 20000;

let running = false;
let stopped = false;

async function request(baseUrl, key, path, { method = 'GET', body, prefer } = {}) {
  const headers = {
    apikey: key,
    Authorization: `Bearer ${key}`,
    Accept: 'application/json',
  };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (prefer) headers.Prefer = prefer;

  const response = await fetch(`${baseUrl}/rest/v1/${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(requestTimeoutMs),
  });

  if (!response.ok) {
    const message = (await response.text()).slice(0, 500);
    throw new Error(`Supabase request failed (${response.status}): ${message}`);
  }
  if (response.status === 204) return null;
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

async function rpc(functionName, parameters) {
  return request(cloudBaseUrl, cloudAnonKey, `rpc/${functionName}`, {
    method: 'POST',
    body: parameters,
  });
}

async function readCursor() {
  const rows = await request(
    localBaseUrl,
    localKey,
    'business_local_sync_meta?key=eq.cloud_cursor&select=value&limit=1'
  );
  const cursor = Number(rows?.[0]?.value || 0);
  return Number.isSafeInteger(cursor) && cursor >= 0 ? cursor : 0;
}

async function pushLocalEvents() {
  const query = new URLSearchParams({
    select: 'event_id,event_type,payload,created_at',
    synced_at: 'is.null',
    order: 'created_at.asc',
    limit: String(batchSize),
  });
  const events = await request(
    localBaseUrl,
    localKey,
    `business_local_sync_outbox?${query.toString()}`
  );
  if (!events?.length) return 0;

  const result = await rpc('push_business_local_sync_events', {
    p_node_id: nodeId,
    p_node_secret: nodeSecret,
    p_events: events.map(({ event_id, event_type, payload }) => ({
      event_id,
      event_type,
      payload,
    })),
  });
  if (!result?.success) throw new Error(result?.error || 'Cloud rejected the local sync batch.');

  const acknowledgedIds = events.map((event) => event.event_id);
  const idFilter = `in.(${acknowledgedIds.join(',')})`;
  await request(
    localBaseUrl,
    localKey,
    `business_local_sync_outbox?event_id=${encodeURIComponent(idFilter)}`,
    {
      method: 'PATCH',
      body: { synced_at: new Date().toISOString(), last_error: null },
      prefer: 'return=minimal',
    }
  );
  return acknowledgedIds.length;
}

async function recordPullFailure(error) {
  const pending = await request(
    localBaseUrl,
    localKey,
    'business_local_sync_meta?key=eq.last_pull_error'
  );
  const message = String(error?.message || error).slice(0, 1000);
  const record = { key: 'last_pull_error', value: message, updated_at: new Date().toISOString() };
  if (pending?.length) {
    await request(
      localBaseUrl,
      localKey,
      'business_local_sync_meta?key=eq.last_pull_error',
      { method: 'PATCH', body: record, prefer: 'return=minimal' }
    );
  } else {
    await request(
      localBaseUrl,
      localKey,
      'business_local_sync_meta?on_conflict=key',
      { method: 'POST', body: record, prefer: 'resolution=merge-duplicates,return=minimal' }
    );
  }
}

async function pullCloudEvents() {
  const cursor = await readCursor();
  const result = await rpc('pull_business_local_sync_events', {
    p_node_id: nodeId,
    p_node_secret: nodeSecret,
    p_after_event_id: cursor,
    p_limit: batchSize,
  });
  if (!result?.success) throw new Error(result?.error || 'Cloud rejected the local server credentials.');

  const events = Array.isArray(result.events) ? result.events : [];
  if (events.length) {
    const rows = events.map((event) => ({
      cursor: event.cursor,
      event_id: event.event_id,
      event_type: event.event_type,
      payload: event.payload,
      created_at: event.created_at,
      received_at: new Date().toISOString(),
    }));
    await request(
      localBaseUrl,
      localKey,
      'business_local_sync_inbox?on_conflict=event_id',
      { method: 'POST', body: rows, prefer: 'resolution=ignore-duplicates,return=minimal' }
    );
  }

  const nextCursor = Number(result.nextCursor);
  if (Number.isSafeInteger(nextCursor) && nextCursor >= cursor) {
    await request(
      localBaseUrl,
      localKey,
      'business_local_sync_meta?on_conflict=key',
      {
        method: 'POST',
        body: {
          key: 'cloud_cursor',
          value: String(nextCursor),
          updated_at: new Date().toISOString(),
        },
        prefer: 'resolution=merge-duplicates,return=minimal',
      }
    );
  }

  await request(
    localBaseUrl,
    localKey,
    'business_local_sync_meta?on_conflict=key',
    {
      method: 'POST',
      body: { key: 'last_pull_error', value: '', updated_at: new Date().toISOString() },
      prefer: 'resolution=merge-duplicates,return=minimal',
    }
  );
  return events.length;
}

async function syncOnce() {
  if (running || stopped) return;
  running = true;
  try {
    const [pushed, pulled] = await Promise.all([pushLocalEvents(), pullCloudEvents()]);
    if (pushed || pulled) console.info(`[local-sync] accepted ${pushed} outbound and received ${pulled} inbound events`);
  } catch (error) {
    console.warn('[local-sync] sync attempt failed; queued events will retry:', error.message);
    try {
      await recordPullFailure(error);
    } catch (statusError) {
      console.warn('[local-sync] could not persist sync status:', statusError.message);
    }
  } finally {
    running = false;
  }
}

const timer = setInterval(syncOnce, pollMs);
timer.unref?.();
syncOnce();

function stop(signal) {
  if (stopped) return;
  stopped = true;
  clearInterval(timer);
  console.info(`[local-sync] stopping after ${signal}`);
  process.exitCode = 0;
}

process.once('SIGTERM', () => stop('SIGTERM'));
process.once('SIGINT', () => stop('SIGINT'));
